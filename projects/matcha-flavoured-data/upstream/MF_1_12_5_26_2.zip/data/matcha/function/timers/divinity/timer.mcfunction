stopwatch restart minecraft:divinity
function matcha:timers/divinity/on_restart