function matcha:timers/divinity/adamant_armour
function matcha:timers/divinity/electrum_armour