data modify entity @s Offers.Recipes append value \
{\
	"max_uses": 1,\
	"sell": {\
		"count": 1,\
		"id": "minecraft:emerald"\
	},\
	"buy": {\
		"count": 1,\
		"id": "minecraft:poisonous_potato",\
		"components": {\
			"minecraft:item_model": "matcha:kontomire_stew",\
			"minecraft:item_name": {\
				"translate": "item.kleispack.kontomire_stew"\
			},\
			"minecraft:lore": [\
				{\
					"text": "\uE030\uE030\uE030\uE030\uE030\uE030",\
					"color": "red",\
					"italic": false\
				},\
				{\
					"translate": "effect.kleispack.strength",\
					"with": ["5:00"],\
					"color": "#e65f33",\
					"italic": false\
				},\
				{\
					"translate": "effect.kleispack.regeneration",\
					"with": ["1:00"],\
					"color": "#e85e8f",\
					"italic": false\
				}\
			],\
			"!minecraft:food": {},\
			"minecraft:consumable": {\
				"consume_seconds": 1.6,\
				"sound": "minecraft:entity.generic.drink",\
				"has_consume_particles": true,\
				"on_consume_effects": [\
					{\
						"type": "minecraft:apply_effects",\
						"effects": [\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 2,\
								"duration": 144,\
								"show_particles": false,\
								"show_icon": false\
							},\
							{\
								"id": "minecraft:strength",\
								"amplifier": 0,\
								"duration": 6000,\
								"show_particles": false,\
								"show_icon": true\
							},\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 0,\
								"duration": 1200,\
								"show_particles": false,\
								"show_icon": true\
							}\
						]\
					}\
				]\
			},\
			"minecraft:use_remainder": {\
				"id": "minecraft:bowl"\
			}\
		}\
	}\
}\


tag @s add foodChecked