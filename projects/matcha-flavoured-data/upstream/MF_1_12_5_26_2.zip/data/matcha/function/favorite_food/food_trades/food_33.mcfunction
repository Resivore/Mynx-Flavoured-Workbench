data modify entity @s Offers.Recipes append value \
{\
	"max_uses": 1,\
	"sell": {\
		"count": 1,\
		"id": "minecraft:emerald"\
	},\
	"buy": {\
		"count": 1,\
		"id": "minecraft:poisonous_potato",\
		"components": {\
			"minecraft:item_model": "matcha:sweet_berry_danish",\
			"minecraft:item_name": {\
				"translate": "item.kleispack.sweet_berry_danish"\
			},\
			"minecraft:lore": [\
				{\
					"text": "\uE030\uE030\uE030\uE030",\
					"color": "red",\
					"italic": false\
				},\
				{\
					"text": "\uE030\uE030\uE030\uE030 (8:00)",\
					"color": "gray",\
					"italic": false\
				}\
			],\
			"!minecraft:food": {},\
			"minecraft:consumable": {\
				"consume_seconds": 1.6,\
				"has_consume_particles": true,\
				"on_consume_effects": [\
					{\
						"type": "minecraft:apply_effects",\
						"effects": [\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 2,\
								"duration": 96,\
								"show_particles": false,\
								"show_icon": false\
							},\
							{\
								"id": "minecraft:health_boost",\
								"amplifier": 1,\
								"duration": 9600,\
								"show_particles": false,\
								"show_icon": true\
							}\
						]\
					}\
				]\
			}\
		}\
	}\
}\


tag @s add foodChecked