data modify entity @s Offers.Recipes append value \
{\
	"max_uses": 1,\
	"sell": {\
		"count": 1,\
		"id": "minecraft:emerald"\
	},\
	"buy": {\
		"count": 1,\
		"id": "minecraft:poisonous_potato",\
		"components": {\
			"minecraft:item_model": "matcha:oatmeal",\
			"minecraft:item_name": {\
				"translate": "item.kleispack.oatmeal"\
			},\
			"minecraft:lore": [\
				{\
					"text": "\uE030\uE030\uE030\uE030\uE030",\
					"color": "red",\
					"italic": false\
				},\
				{\
					"translate": "effect.kleispack.regeneration",\
					"with": ["2:00"],\
					"color": "#e85e8f",\
					"italic": false\
				},\
				{\
					"translate": "effect.kleispack.speed",\
					"with":["10:00"],\
					"color": "#37cafb",\
					"italic": false\
				}\
			],\
			"!minecraft:food": {},\
			"minecraft:consumable": {\
				"consume_seconds": 1.8,\
				"has_consume_particles": true,\
				"on_consume_effects": [\
					{\
						"type": "minecraft:apply_effects",\
						"effects": [\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 2,\
								"duration": 120,\
								"show_particles": false,\
								"show_icon": false\
							},\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 0,\
								"duration": 2400,\
								"show_particles": false,\
								"show_icon": true\
							},\
							{\
								"id": "minecraft:speed",\
								"amplifier": 0,\
								"duration": 12000,\
								"show_particles": false,\
								"show_icon": true\
							}\
						]\
					}\
				]\
			},\
			"minecraft:use_remainder": {\
				"id": "minecraft:bowl"\
			}\
		}\
	}\
}\


tag @s add foodChecked