data modify entity @s Offers.Recipes append value \
{\
	"max_uses": 1,\
	"sell": {\
		"count": 1,\
		"id": "minecraft:emerald"\
	},\
	"buy": {\
		"count": 1,\
		"id": "minecraft:poisonous_potato",\
		"components": {\
			"minecraft:item_model": "matcha:mead",\
			"minecraft:item_name": {\
				"translate": "item.kleispack.mead"\
			},\
			"minecraft:lore": [\
				{\
					"text": "\uE030\uE030\uE030",\
					"color": "red",\
					"italic": false\
				},\
				{\
					"translate": "effect.kleispack.speed",\
					"with":["5:00"],\
					"color": "#37cafb",\
					"italic": false\
				}\
			],\
			"!minecraft:food": {},\
			"minecraft:consumable": {\
				"consume_seconds": 1.6,\
				"animation": "drink",\
				"sound": "minecraft:item.honey_bottle.drink",\
				"has_consume_particles": false,\
				"on_consume_effects": [\
					{\
						"type": "minecraft:apply_effects",\
						"effects": [\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 2,\
								"duration": 72,\
								"show_particles": false,\
								"show_icon": false\
							},\
							{\
								"id": "minecraft:speed",\
								"amplifier": 0,\
								"duration": 6000,\
								"show_particles": false,\
								"show_icon": true\
							}\
						]\
					}\
				]\
			},\
			"minecraft:use_remainder": {\
				"id": "minecraft:glass_bottle"\
			}\
		}\
	}\
}\


tag @s add foodChecked