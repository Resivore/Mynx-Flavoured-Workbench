data modify entity @s Offers.Recipes append value \
{\
	"max_uses": 1,\
	"sell": {\
		"count": 1,\
		"id": "minecraft:emerald"\
	},\
	"buy": {\
		"count": 1,\
		"id": "minecraft:poisonous_potato",\
		"components": {\
			"minecraft:item_model": "matcha:honey_ginger_tea",\
			"minecraft:item_name": {\
				"translate": "item.kleispack.honey_ginger_tea"\
			},\
			"minecraft:lore": [\
				{\
					"text": "\uE030",\
					"color": "red",\
					"italic": false\
				},\
				{\
					"translate": "effect.kleispack.speed",\
					"with":["0:30"],\
					"color": "#37cafb",\
					"italic": false\
				},\
				{\
					"translate": "desc.kleispack.cleanses_maleffect",\
					"color": "gray",\
					"italic": false\
				}\
			],\
			"!minecraft:food": {},\
			"minecraft:consumable": {\
				"consume_seconds": 0.8,\
				"animation": "drink",\
				"sound": "minecraft:entity.generic.drink",\
				"has_consume_particles": false,\
				"on_consume_effects": [\
					{\
						"type": "minecraft:apply_effects",\
						"effects": [\
							{\
								"id": "minecraft:regeneration",\
								"amplifier": 2,\
								"duration": 24,\
								"show_particles": false,\
								"show_icon": false\
							},\
							{\
								"id": "minecraft:speed",\
								"amplifier": 0,\
								"duration": 600,\
								"show_particles": false,\
								"show_icon": true\
							}\
						]\
					},\
					{\
						"type": "minecraft:remove_effects",\
						"effects": "#matcha:harmful"\
					}\
				]\
			},\
			"minecraft:use_remainder": {\
				"id": "minecraft:glass_bottle"\
			}\
		}\
	}\
}\


tag @s add foodChecked